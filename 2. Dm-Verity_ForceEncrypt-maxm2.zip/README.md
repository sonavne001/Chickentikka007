# Disables Verity, Forceencrypt, and/or Disc Quota
Heavily based on previous work by topjohnwu and jcadduono
